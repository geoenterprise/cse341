const geoRoute = (req, res) => {
    res.send('Jovanny Rey');
};

const anaRoute = (req, res) => {
    res.send('Ana Criollo');
};

module.exports = {
    geoRoute,
    anaRoute,
};